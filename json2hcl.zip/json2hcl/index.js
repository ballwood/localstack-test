const test = require('./test.json');
const { is } = require('ramda');
const { snakeCase } = require('lodash');

const isArray = is(Array);
const isObject = is(Object);
const isIntrinsic = (item) => {
  return item && (item['Fn::Join'] || item['Fn::Sub'] || item['Fn::GetAtt'] || item['Ref']);
};

const entriesFor = Object.entries;

const fromPairs = (pairs) => {

  return pairs.reduce((res, [key, value]) => {

    return {
      ...res,
      [key]: value
    }

  }, {});

};

const processCfTemplateValues = (funcValue, node) => {

  // is array
  if (isArray(node)) {
    return node.map((item) => {
      return funcValue(item);
    })
  }

  // is obj
  if (isObject(node)) {

    const props = entriesFor(node);

    const mapper = props.map(([key, value]) => {
      return [key, funcValue(value)]
    });

    return fromPairs(mapper);

  }

  return node;
};

const processCfTemplateNames = (funcName, node) => {

  if (isArray(node)) {
    return node.map((item) => {
      return processCfTemplateNames(funcName, item);
    })
  }

  // is obj
  if (isObject(node)) {

    const props = entriesFor(node);

    const mapper = props.map(([key, value]) => {
      return [funcName(key), processCfTemplateNames(funcName, value)]
    });

    return fromPairs(mapper);

  }

  return node;

};

const replaceIntrinsic = (node) => {

  if (isIntrinsic(node)) {

    if (node['Fn::Join']) {
      const vals = processCfTemplateValues(replaceIntrinsic, node['Fn::Join'][1]);
      return vals.join(node['Fn::Join'][0])
    }

    if (node['Fn::Sub']) {
      return node['Fn::Sub'];
    }

    if (node['Fn::GetAtt']) {
      return "${" + node['Fn::GetAtt'].join('.') + "}";
    }

    if (node['Ref']) {
      return "${" + node['Ref'] + ".id}";
    }

  }

  return processCfTemplateValues(replaceIntrinsic, node);

};

const awsSnakeCase = (name) => {

  switch (name) {
    case 'Fn::Join':
    case 'Fn::Sub':
    case 'Fn::GetAtt':
    case 'Ref':
      return name;
  }

  return snakeCase(name);

};

const replaceNames = (node) => {

  const resourceEntries = entriesFor(node.Resources);

  const newResources = resourceEntries.reduce((res, [key, value]) => {

    return {
      ...res,
      [key]: processCfTemplateNames(awsSnakeCase, value)
    }

  }, {});

  return {
    ...node,
    Resources: newResources
  }

};

const hclResourceType = (name) => {
  return name.replace(/\:\:/g, '_').toLowerCase();
};

const replaceResourceTypes = (template) => {

  const resourcePairs = entriesFor(template.Resources);

  const newResources = fromPairs(resourcePairs.map(([key, value]) => {
    return [
      key,
      {
        ...value,
        type: hclResourceType(value.Type)
      }
    ]
  }));

  return {
    ...template,
    Resources: newResources
  }

};

const padStr = (str, pad) => {
  let res = '';
  for (let i=0; i<pad; i++) {
    res += ' ';
  }
  return res + str;
};

const toHcl = (item, indent = 2) => {

  if (isArray(item)) {
    const vals = item.map((value) => {
      return padStr(`${toHcl(value, indent + 2)}`, indent)
    }).join(',\n') + '\n';

    return '[\n' + vals + padStr(']\n', indent - 2);

  }

  if (isObject(item)) {

    const vals = entriesFor(item).map(([key, value]) => {
      return padStr(`${key} = ${toHcl(value, indent + 2)}`, indent)
    }).join('\n') + '\n';

    return '{\n' + vals + padStr('}\n', indent - 2);

  }

  return `"${item.toString()}"`

};

const resourcesToHcl = (cf) => {

  return entriesFor(cf.Resources).reduce((res, [key, value]) => {

    res += `resource "${value.type}" "${key}" `;
    res += toHcl(value.properties);
    res += `\n`;

    return res;

  }, '');

};

const xyz = {
  "a": {
    "b": {
      "c": 1
    }
  }
};

// console.log(toHcl(xyz));

const res = resourcesToHcl(replaceIntrinsic(replaceNames(replaceResourceTypes(test))));
console.log(res);